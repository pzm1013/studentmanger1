package entity;

import java.util.Date;

public class Systemm {
	private Integer sysid;
	private Integer forbitc;
	private Integer forbist;
	private String informtc;
	private String informst;
	public Integer getSysid() {
		return sysid;
	}
	public void setSysid(Integer sysid) {
		this.sysid = sysid;
	}
	public Integer getForbitc() {
		return forbitc;
	}
	public void setForbitc(Integer forbitc) {
		this.forbitc = forbitc;
	}
	public Integer getForbist() {
		return forbist;
	}
	public void setForbist(Integer forbist) {
		this.forbist = forbist;
	}
	public String getInformtc() {
		return informtc;
	}
	public void setInformtc(String informtc) {
		this.informtc = informtc;
	}
	public String getInformst() {
		return informst;
	}
	public void setInformst(String informst) {
		this.informst = informst;
	}
	
	

}
