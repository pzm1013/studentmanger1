package dao;

import javax.servlet.http.HttpServletRequest;

import entity.Systemm;

public interface ISystem
{
	

	public String system(HttpServletRequest request, Systemm system);

}
